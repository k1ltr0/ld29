
// ***** gxtkGraphics.h *****

class gxtkSurface;

class gxtkGraphics : public Object{
public:
	gxtkGraphics();
	
	virtual int Width();
	virtual int Height();
	
	virtual int  BeginRender();
	virtual void EndRender();
	virtual void DiscardGraphics();
	
	virtual gxtkSurface *LoadSurface__UNSAFE__( gxtkSurface *surface,String path );
	virtual gxtkSurface *LoadSurface( String path );
	virtual gxtkSurface *CreateSurface( int width,int height );
	
	virtual int Cls( float red,float g,float b );
	virtual int SetAlpha( float alpha );
	virtual int SetColor( float r,float g,float b );
	virtual int SetMatrix( float ix,float iy,float jx,float jy,float tx,float ty );
	virtual int SetScissor( int x,int y,int width,int height );
	virtual int SetBlend( int blend );
	
	virtual int DrawPoint( float x,float y );
	virtual int DrawRect( float x,float y,float w,float h );
	virtual int DrawLine( float x1,float y1,float x2,float y2 );
	virtual int DrawOval( float x,float y,float w,float h );
	virtual int DrawPoly( Array<Float> verts );
	virtual int DrawPoly2( Array<Float> verts,gxtkSurface *surface,int srcx,int srcy );
	virtual int DrawSurface( gxtkSurface *surface,float x,float y );
	virtual int DrawSurface2( gxtkSurface *surface,float x,float y,int srcx,int srcy,int srcw,int srch );
	
	virtual int ReadPixels( Array<int> pixels,int x,int y,int width,int height,int offset,int pitch );
	virtual int WritePixels2( gxtkSurface *surface,Array<int> pixels,int x,int y,int width,int height,int offset,int pitch );
	
	// ***** INTERNAL *****
	struct Vertex{
		float x,y,u,v;
		unsigned int color;
	};
	
	struct ShaderConstants{
		DirectX::XMFLOAT4X4 projection;
	};

	enum{
		MAX_VERTS=1024,
		MAX_POINTS=MAX_VERTS,
		MAX_LINES=MAX_VERTS/2,
		MAX_QUADS=MAX_VERTS/4
	};
	
	Vertex *primVerts,*nextVert;
	int primType;
	gxtkSurface *primSurf;
	gxtkSurface *devPrimSurf;
	D3D11_PRIMITIVE_TOPOLOGY primTop;
	
	unsigned short quadIndices[MAX_QUADS*6]; 

	int gwidth,gheight;
	int dwidth,dheight;
	DirectX::XMFLOAT4X4 omatrix;
	
	float ix,iy,jx,jy,tx,ty;
	bool tformed;

	float r,g,b,alpha;
	unsigned int color;
	
	D3D11_RECT scissorRect;
	
	ShaderConstants shaderConstants;
	
	ID3D11Device1 *d3dDevice;
	ID3D11DeviceContext1 *d3dContext;
	
	// ***** D3d resources *****
	//
	ID3D11VertexShader *simpleVertexShader;
	ID3D11PixelShader *simplePixelShader;
	ID3D11VertexShader *textureVertexShader;
	ID3D11PixelShader *texturePixelShader;
	
	ID3D11InputLayout *inputLayout;
	ID3D11Buffer *vertexBuffer;
	ID3D11Buffer *indexBuffer;
	ID3D11Buffer *indexBuffer2;
	ID3D11Buffer *constantBuffer;
	
	ID3D11BlendState *alphaBlendState;
	ID3D11BlendState *additiveBlendState;
	ID3D11RasterizerState *rasterizerState;
	ID3D11DepthStencilState *depthStencilState;
	ID3D11SamplerState *samplerState;

	void MapVB();
	void UnmapVB();
	void CreateD3dResources();
	void Flush();
	void ValidateSize();
	D3D11_RECT DisplayRect( int x,int y,int w,int h );
	Vertex *Begin( int type,gxtkSurface *surf );

};

class gxtkSurface : public Object{
public:
	gxtkGraphics *graphics;
	ID3D11Texture2D *texture;
	ID3D11ShaderResourceView *resourceView;
	int width,height;
	float uscale,vscale;

	gxtkSurface( gxtkGraphics *graphics );
	~gxtkSurface();
	
	void SetTexture( ID3D11Texture2D *texture );
	
	virtual void Discard();
	
	virtual int Width();
	virtual int Height();
};

//***** gxtkGraphics.cpp *****

using namespace DirectX;
using namespace Windows::Graphics::Display;

gxtkGraphics::gxtkGraphics(){
	
	d3dDevice=BBWin8Game::Win8Game()->GetD3dDevice();
	d3dContext=BBWin8Game::Win8Game()->GetD3dContext();
	
	CreateD3dResources();
	
	unsigned short *indices=new unsigned short[ max( MAX_QUADS*6,(MAX_VERTS-2)*3 ) ];
	
	//indices for quads
	for( int i=0;i<MAX_QUADS;++i ){
		indices[i*6  ]=(unsigned short)(i*4);
		indices[i*6+1]=(unsigned short)(i*4+1);
		indices[i*6+2]=(unsigned short)(i*4+2);
		indices[i*6+3]=(unsigned short)(i*4);
		indices[i*6+4]=(unsigned short)(i*4+2);
		indices[i*6+5]=(unsigned short)(i*4+3);
	}
	D3D11_BOX box={0,0,0,MAX_QUADS*6*sizeof( unsigned short ),1,1};
	d3dContext->UpdateSubresource( indexBuffer,0,&box,indices,0,0 );
	
	//indices for trifan
	for( int i=0;i<MAX_VERTS-2;++i ){
		indices[i*3  ]=(unsigned short)0;
		indices[i*3+1]=(unsigned short)(i+1);
		indices[i*3+2]=(unsigned short)(i+2);
	}
	D3D11_BOX box2={0,0,0,(MAX_VERTS-2)*3*sizeof( unsigned short ),1,1};
	d3dContext->UpdateSubresource( indexBuffer2,0,&box2,indices,0,0 );
	
	delete[] indices;
	
	ValidateSize();
}

void gxtkGraphics::ValidateSize(){

	DXGI_SWAP_CHAIN_DESC1 scdesc;
	DXASS( BBWin8Game::Win8Game()->GetSwapChain()->GetDesc1( &scdesc ) );
	
	gwidth=dwidth=scdesc.Width;
	gheight=dheight=scdesc.Height;

	ZEROMEM( omatrix );
	
	int devrot=BBWin8Game::Win8Game()->GetDeviceRotation();
	
	switch( devrot ){
	case 0:
		omatrix._11=omatrix._22=1;
		omatrix._33=omatrix._44=1;
		break;
	case 1:
		omatrix._11= 0;omatrix._12=-1;
		omatrix._21= 1;omatrix._22= 0;
		omatrix._33=omatrix._44=1;
		break;
	case 2:
		omatrix._11=-1;omatrix._12= 0;
		omatrix._21= 0;omatrix._22=-1;
		omatrix._33=omatrix._44=1;
		break;
	case 3:
		omatrix._11= 0;omatrix._12= 1;
		omatrix._21=-1;omatrix._22= 0;
		omatrix._33=omatrix._44=1;
		break;
	}
	
#if WINDOWS_8
	if( devrot & 1 ){
		gwidth=dheight;
		gheight=dwidth;
	}
#endif	
#if WINDOWS_PHONE_8
	if( devrot & 1 ){
		gwidth=dheight;
		gheight=dwidth;
	}
#endif

}

D3D11_RECT gxtkGraphics::DisplayRect( int x,int y,int width,int height ){

	int x0,y0,x1,y1;
	
	int devrot=BBWin8Game::Win8Game()->GetDeviceRotation();

	switch( devrot ){
	case 0:
		x0=x;
		y0=y;
		x1=x0+width;
		y1=y0+height;
		break;
	case 1:
		x0=dwidth-y-height;
		y0=x;
		x1=x0+height;
		y1=y0+width;
		break;
	case 2:
		x0=dwidth-x-width;
		y0=dheight-y-height;
		x1=x0+width;
		y1=y0+height;
		break;
	case 3:
		x0=y;
		y0=dheight-x-width;
		x1=x0+height;
		y1=y0+width;
		break;
	}
	D3D11_RECT rect={x0,y0,x1,y1};
	return rect;
}

void gxtkGraphics::MapVB(){
	if( primVerts ) return;
	D3D11_MAPPED_SUBRESOURCE msr;
	d3dContext->Map( vertexBuffer,0,D3D11_MAP_WRITE_DISCARD,0,&msr );
	primVerts=(Vertex*)msr.pData;
}

void gxtkGraphics::UnmapVB(){
	if( !primVerts ) return;
	d3dContext->Unmap( vertexBuffer,0 );
	primVerts=0;
}

void gxtkGraphics::Flush(){
	if( !primType ) return;

	int n=nextVert-primVerts;
	
	UnmapVB();
	
	if( primSurf!=devPrimSurf ){
		if( devPrimSurf=primSurf ){
			d3dContext->VSSetShader( textureVertexShader,0,0 );
			d3dContext->PSSetShader( texturePixelShader,0,0 );
			d3dContext->PSSetShaderResources( 0,1,&primSurf->resourceView );
		}else{
			d3dContext->VSSetShader( simpleVertexShader,0,0 );
			d3dContext->PSSetShader( simplePixelShader,0,0 );
			d3dContext->PSSetShaderResources( 0,0,0 );
		}
	}
	
	switch( primType ){
	case 1:
		if( primTop!=D3D11_PRIMITIVE_TOPOLOGY_POINTLIST ){
			primTop=D3D11_PRIMITIVE_TOPOLOGY_POINTLIST;
			d3dContext->IASetPrimitiveTopology( primTop );
		}
		d3dContext->Draw( n,0 );
		break;
	case 2:
		if( primTop!=D3D11_PRIMITIVE_TOPOLOGY_LINELIST ){
			primTop=D3D11_PRIMITIVE_TOPOLOGY_LINELIST;
			d3dContext->IASetPrimitiveTopology( primTop );
		}
		d3dContext->Draw( n,0 );
		break;
	case 3:
		if( primTop!=D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST ){
			primTop=D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST;
			d3dContext->IASetPrimitiveTopology( primTop );
		}
		d3dContext->Draw( n,0 );
		break;
	case 4:
		if( primTop!=D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST ){
			primTop=D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST;
			d3dContext->IASetPrimitiveTopology( primTop );
		}
		d3dContext->DrawIndexed( n/4*6,0,0 );
		break;
	default:
		if( primTop!=D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST ){
			primTop=D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST;
			d3dContext->IASetPrimitiveTopology( primTop );
		}
		d3dContext->IASetIndexBuffer( indexBuffer2,DXGI_FORMAT_R16_UINT,0 );
		for( int j=0;j<n;j+=primType){
			d3dContext->DrawIndexed( (primType-2)*3,0,j );
		}
		d3dContext->IASetIndexBuffer( indexBuffer,DXGI_FORMAT_R16_UINT,0 );
		break;	
	}
	
	primType=0;
}

gxtkGraphics::Vertex *gxtkGraphics::Begin( int type,gxtkSurface *surf ){
	if( type!=primType || surf!=primSurf || (nextVert+type)-primVerts>MAX_VERTS ){
		Flush();
		MapVB();
		nextVert=primVerts;
		primType=type;
		primSurf=surf;
	}
	Vertex *v=nextVert;
	nextVert+=type;
	return v;
}

//***** gxtk API *****

int gxtkGraphics::Width(){
	return gwidth;
}

int gxtkGraphics::Height(){
	return gheight;
}

int  gxtkGraphics::BeginRender(){

	ValidateSize();
	
	XMStoreFloat4x4( 
		&shaderConstants.projection,
		XMMatrixTranspose( 
			XMMatrixMultiply( 
				XMMatrixOrthographicOffCenterLH( 0,Width(),Height(),0,-1,1 ),
				XMLoadFloat4x4( &omatrix ) ) ) );

	ID3D11RenderTargetView *rtv=BBWin8Game::Win8Game()->GetRenderTargetView();
	
	d3dContext->OMSetRenderTargets( 1,&rtv,0 );
	
	d3dContext->OMSetDepthStencilState( depthStencilState,0 );
	
	d3dContext->UpdateSubresource( constantBuffer,0,0,&shaderConstants,0,0 );
	
	UINT stride=sizeof( Vertex ),offset=0;
	d3dContext->IASetVertexBuffers( 0,1,&vertexBuffer,&stride,&offset );
	
	d3dContext->IASetIndexBuffer( indexBuffer,DXGI_FORMAT_R16_UINT,0 );

	d3dContext->IASetInputLayout( inputLayout );

	d3dContext->VSSetConstantBuffers( 0,1,&constantBuffer	);

	d3dContext->OMSetBlendState( alphaBlendState,0,~0 );

	d3dContext->VSSetShader( simpleVertexShader,0,0 );
	
	d3dContext->PSSetShader( simplePixelShader,0,0 );
	
	d3dContext->PSSetSamplers( 0,1,&samplerState );
	
	d3dContext->RSSetState( rasterizerState );
	
	d3dContext->RSSetScissorRects( 0,0 );
	
	primVerts=0;
	primType=0;
	primSurf=0;
	devPrimSurf=0;
	primTop=D3D11_PRIMITIVE_TOPOLOGY_UNDEFINED;
	
	ix=1;iy=0;jx=0;jy=1;tx=0;ty=0;tformed=false;
	
	r=255;g=255;b=255;alpha=1;color=0xffffffff;

	return 1;
}

void gxtkGraphics::EndRender(){

	Flush();

	HRESULT hr=BBWin8Game::Win8Game()->GetSwapChain()->Present( 1,0 );

	d3dContext->DiscardView( BBWin8Game::Win8Game()->GetRenderTargetView() );
//	d3dContext->DiscardView( BBWin8Game::Win8Game()->GetDepthStencilView() );

	if( hr==DXGI_ERROR_DEVICE_REMOVED ){
		//device lost...
		exit( 0 );
	}else{
		DXASS( hr );
	}
}

void gxtkGraphics::DiscardGraphics(){
}

gxtkSurface *gxtkGraphics::LoadSurface__UNSAFE__( gxtkSurface *surface,String path ){

	int width,height,format;
	
	unsigned char *data=BBWin8Game::Win8Game()->LoadImageData( path,&width,&height,&format );
	if( ! data ) return 0;
	
	if( format==4 ){
		unsigned char *p=data;
		for( int n=width*height;n>0;--n ){ p[0]=p[0]*p[3]/255;p[1]=p[1]*p[3]/255;p[2]=p[2]*p[3]/255;p+=4; }
	}else if( format==3 ){
		unsigned char *out=(unsigned char*)malloc( width*height*4 );
		unsigned char *s=data,*d=out;
		for( int n=width*height;n>0;--n ){ *d++=*s++;*d++=*s++;*d++=*s++;*d++=255; }
		free( data );
		data=out;
		format=4;
	}else{
		Print( String( "Bad image format: path=" )+path+", format="+format );
		free( data );
		return 0;
	}
	
	D3D11_TEXTURE2D_DESC txdesc;
	txdesc.Width=width;
	txdesc.Height=height;
	txdesc.MipLevels=1;
	txdesc.ArraySize=1;
	txdesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;
	txdesc.SampleDesc.Count=1;
	txdesc.SampleDesc.Quality=0;
	txdesc.Usage=D3D11_USAGE_DEFAULT;
	txdesc.BindFlags=D3D11_BIND_SHADER_RESOURCE;
	txdesc.CPUAccessFlags=0;
	txdesc.MiscFlags=0;

	D3D11_SUBRESOURCE_DATA txdata={ data,width*4,0 };
	
	ID3D11Texture2D *texture;
	if( SUCCEEDED( d3dDevice->CreateTexture2D( &txdesc,&txdata,&texture ) ) ){
		surface->SetTexture( texture );
	}else{
		surface=0;
	}
	free( data );
	return surface;
}

gxtkSurface *gxtkGraphics::LoadSurface( String path ){
	return LoadSurface__UNSAFE__( new gxtkSurface( this ),path );
}

gxtkSurface *gxtkGraphics::CreateSurface( int width,int height ){

	D3D11_TEXTURE2D_DESC txdesc;
	txdesc.Width=width;
	txdesc.Height=height;
	txdesc.MipLevels=1;
	txdesc.ArraySize=1;
	txdesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;
	txdesc.SampleDesc.Count=1;
	txdesc.SampleDesc.Quality=0;
	txdesc.Usage=D3D11_USAGE_DEFAULT;
	txdesc.BindFlags=D3D11_BIND_SHADER_RESOURCE;
	txdesc.CPUAccessFlags=0;
	txdesc.MiscFlags=0;

	ID3D11Texture2D *texture;
	if( !SUCCEEDED( d3dDevice->CreateTexture2D( &txdesc,0,&texture ) ) ){
		return 0;
	}
	
	gxtkSurface *surface=new gxtkSurface( this );
	
	surface->SetTexture( texture );
	
	return surface;
}

int gxtkGraphics::WritePixels2( gxtkSurface *surface,Array<int> pixels,int x,int y,int width,int height,int offset,int pitch ){

	unsigned *p=(unsigned*)malloc(width*height*4);
	unsigned *d=p;
	for( int py=0;py<height;++py ){
		unsigned *s=(unsigned*)&pixels[offset+py*pitch];
		for( int px=0;px<width;++px ){
			unsigned p=*s++;
			unsigned a=p>>24;
			*d++=(a<<24) | ((p&0xff)*a/255<<16) | ((p>>8&0xff)*a/255<<8) | ((p>>16&0xff)*a/255);
		}
	}

	D3D11_BOX box={x,y,0,x+width,y+height,1};
	
	d3dContext->UpdateSubresource( surface->texture,0,&box,p,width*4,0 );

	free( p );
	
	return 0;
}

int gxtkGraphics::Cls( float r,float g,float b ){

	if( scissorRect.left!=0 || scissorRect.top!=0 || scissorRect.right!=gwidth || scissorRect.bottom!=gheight ){
	
		float x0=scissorRect.left;
		float x1=scissorRect.right;
		float y0=scissorRect.top;
		float y1=scissorRect.bottom;
		unsigned color=0xff000000 | (int(b)<<16) | (int(g)<<8) | int(r);
		
		MapVB();
		primType=4;
		primSurf=0;
		Vertex *v=primVerts;
		nextVert=v+4;
		
		v[0].x=x0;v[0].y=y0;v[0].color=color;
		v[1].x=x1;v[1].y=y0;v[1].color=color;
		v[2].x=x1;v[2].y=y1;v[2].color=color;
		v[3].x=x0;v[3].y=y1;v[3].color=color;
		
	}else{
	
		UnmapVB();
		primType=0;
		
		float rgba[]={ r/255.0f,g/255.0f,b/255.0f,1.0f };
		d3dContext->ClearRenderTargetView( BBWin8Game::Win8Game()->GetRenderTargetView(),rgba );
	}
	
	return 0;
}


int gxtkGraphics::SetAlpha( float alpha ){

	this->alpha=alpha;
	
	color=(int(alpha*255)<<24) | (int(b*alpha)<<16) | (int(g*alpha)<<8) | int(r*alpha);
	
	return 0;
}

int gxtkGraphics::SetColor( float r,float g,float b ){

	this->r=r;this->g=g;this->b=b;
	
	color=(int(alpha*255)<<24) | (int(b*alpha)<<16) | (int(g*alpha)<<8) | int(r*alpha);

	return 0;
}

int gxtkGraphics::SetMatrix( float ix,float iy,float jx,float jy,float tx,float ty ){

	this->ix=ix;this->iy=iy;this->jx=jx;this->jy=jy;this->tx=tx;this->ty=ty;

	tformed=(ix!=1 || iy!=0 || jx!=0 || jy!=1 || tx!=0 || ty!=0);

	return 0;
}

int gxtkGraphics::SetScissor( int x,int y,int width,int height ){

	Flush();
	
	scissorRect.left=x;scissorRect.top=y;
	scissorRect.right=x+width;scissorRect.bottom=y+height;
	
	D3D11_RECT rect=DisplayRect( x,y,width,height );
	d3dContext->RSSetScissorRects( 1,&rect );

	return 0;
}

int gxtkGraphics::SetBlend( int blend ){
	
	Flush();
	
	switch( blend ){
	case 1:
		d3dContext->OMSetBlendState( additiveBlendState,0,~0 );
		break;
	default:
		d3dContext->OMSetBlendState( alphaBlendState,0,~0 );
	}

	return 0;
}

int gxtkGraphics::DrawPoint( float x0,float y0 ){

	if( tformed ){
		float tx0=x0;
		x0=tx0 * ix + y0 * jx + tx;
		y0=tx0 * iy + y0 * jy + ty;
	}
	
	Vertex *v=Begin( 1,0 );

	v[0].x=x0;v[0].y=y0;v[0].color=color;

	return 0;
}

int gxtkGraphics::DrawLine( float x0,float y0,float x1,float y1 ){

	if( tformed ){
		float tx0=x0,tx1=x1;
		x0=tx0 * ix + y0 * jx + tx;
		y0=tx0 * iy + y0 * jy + ty;
		x1=tx1 * ix + y1 * jx + tx;
		y1=tx1 * iy + y1 * jy + ty;
	}

	Vertex *v=Begin( 2,0 );

	v[0].x=x0;v[0].y=y0;v[0].color=color;
	v[1].x=x1;v[1].y=y1;v[1].color=color;

	return 0;
}

int gxtkGraphics::DrawRect( float x,float y,float w,float h ){

	float x0=x,x1=x+w,x2=x+w,x3=x;
	float y0=y,y1=y,y2=y+h,y3=y+h;
	
	if( tformed ){
		float tx0=x0,tx1=x1,tx2=x2,tx3=x3;
		x0=tx0 * ix + y0 * jx + tx;
		y0=tx0 * iy + y0 * jy + ty;
		x1=tx1 * ix + y1 * jx + tx;
		y1=tx1 * iy + y1 * jy + ty;
		x2=tx2 * ix + y2 * jx + tx;
		y2=tx2 * iy + y2 * jy + ty;
		x3=tx3 * ix + y3 * jx + tx;
		y3=tx3 * iy + y3 * jy + ty;
	}
	
	Vertex *v=Begin( 4,0 );
	
	v[0].x=x0;v[0].y=y0;v[0].color=color;
	v[1].x=x1;v[1].y=y1;v[1].color=color;
	v[2].x=x2;v[2].y=y2;v[2].color=color;
	v[3].x=x3;v[3].y=y3;v[3].color=color;
	
	return 0;
}

int gxtkGraphics::DrawOval( float x,float y,float w,float h ){

	float xr=w/2.0f;
	float yr=h/2.0f;

	int segs;
	if( tformed ){
		float dx_x=xr * ix;
		float dx_y=xr * iy;
		float dx=sqrtf( dx_x*dx_x+dx_y*dx_y );
		float dy_x=yr * jx;
		float dy_y=yr * jy;
		float dy=sqrtf( dy_x*dy_x+dy_y*dy_y );
		segs=(int)( dx+dy );
	}else{
		segs=(int)( abs( xr )+abs( yr ) );
	}
	
	if( segs<12 ){
		segs=12;
	}else if( segs>MAX_VERTS ){
		segs=MAX_VERTS;
	}else{
		segs&=~3;
	}
	
	x+=xr;
	y+=yr;
	
	Vertex *v=Begin( segs,0 );

	for( int i=0;i<segs;++i ){
	
		float th=i * 6.28318531f / segs;

		float x0=x+cosf( th ) * xr;
		float y0=y-sinf( th ) * yr;
		
		if( tformed ){
			float tx0=x0;
			x0=tx0 * ix + y0 * jx + tx;
			y0=tx0 * iy + y0 * jy + ty;
		}
		v[i].x=x0;v[i].y=y0;v[i].color=color;
	}

	return 0;
}

int gxtkGraphics::DrawPoly( Array<Float> verts ){
	int n=verts.Length()/2;
	if( n<1 || n>MAX_VERTS ) return 0;

	Vertex *v=Begin( n,0 );
	
	for( int i=0;i<n;++i ){
		float x0=verts[i*2];
		float y0=verts[i*2+1];
		if( tformed ){
			float tx0=x0;
			x0=tx0 * ix + y0 * jx + tx;
			y0=tx0 * iy + y0 * jy + ty;
		}
		v[i].x=x0;v[i].y=y0;v[i].color=color;
	}
	return 0;
}

int gxtkGraphics::DrawPoly2( Array<Float> verts,gxtkSurface *surface,int srcx,int srcy ){
	int n=verts.Length()/4;
	if( n<1 || n>MAX_VERTS ) return 0;

	Vertex *v=Begin( n,surface );
	
	for( int i=0;i<n;++i ){
		int j=i*4;
		float x0=verts[j];
		float y0=verts[j+1];
		if( tformed ){
			float tx0=x0;
			x0=tx0 * ix + y0 * jx + tx;
			y0=tx0 * iy + y0 * jy + ty;
		}
		v[i].x=x0;
		v[i].y=y0;
		v[i].u=(srcx+verts[j+2])*surface->uscale;
		v[i].v=(srcy+verts[j+3])*surface->vscale;
		v[i].color=color;
	}
	return 0;
}

int gxtkGraphics::DrawSurface( gxtkSurface *surf,float x,float y ){
	float w=surf->Width();
	float h=surf->Height();
	float x0=x,x1=x+w,x2=x+w,x3=x;
	float y0=y,y1=y,y2=y+h,y3=y+h;
	float u0=0,u1=w*surf->uscale;
	float v0=0,v1=h*surf->vscale;

	if( tformed ){
		float tx0=x0,tx1=x1,tx2=x2,tx3=x3;
		x0=tx0 * ix + y0 * jx + tx;y0=tx0 * iy + y0 * jy + ty;
		x1=tx1 * ix + y1 * jx + tx;y1=tx1 * iy + y1 * jy + ty;
		x2=tx2 * ix + y2 * jx + tx;y2=tx2 * iy + y2 * jy + ty;
		x3=tx3 * ix + y3 * jx + tx;y3=tx3 * iy + y3 * jy + ty;
	}
	
	Vertex *v=Begin( 4,surf );
	
	v[0].x=x0;v[0].y=y0;v[0].u=u0;v[0].v=v0;v[0].color=color;
	v[1].x=x1;v[1].y=y1;v[1].u=u1;v[1].v=v0;v[1].color=color;
	v[2].x=x2;v[2].y=y2;v[2].u=u1;v[2].v=v1;v[2].color=color;
	v[3].x=x3;v[3].y=y3;v[3].u=u0;v[3].v=v1;v[3].color=color;
	
	return 0;
}

int gxtkGraphics::DrawSurface2( gxtkSurface *surf,float x,float y,int srcx,int srcy,int srcw,int srch ){
	float w=srcw;
	float h=srch;
	float x0=x,x1=x+w,x2=x+w,x3=x;
	float y0=y,y1=y,y2=y+h,y3=y+h;
	float u0=srcx*surf->uscale,u1=(srcx+srcw)*surf->uscale;
	float v0=srcy*surf->vscale,v1=(srcy+srch)*surf->vscale;

	if( tformed ){
		float tx0=x0,tx1=x1,tx2=x2,tx3=x3;
		x0=tx0 * ix + y0 * jx + tx;y0=tx0 * iy + y0 * jy + ty;
		x1=tx1 * ix + y1 * jx + tx;y1=tx1 * iy + y1 * jy + ty;
		x2=tx2 * ix + y2 * jx + tx;y2=tx2 * iy + y2 * jy + ty;
		x3=tx3 * ix + y3 * jx + tx;y3=tx3 * iy + y3 * jy + ty;
	}
	
	Vertex *v=Begin( 4,surf );
	
	v[0].x=x0;v[0].y=y0;v[0].u=u0;v[0].v=v0;v[0].color=color;
	v[1].x=x1;v[1].y=y1;v[1].u=u1;v[1].v=v0;v[1].color=color;
	v[2].x=x2;v[2].y=y2;v[2].u=u1;v[2].v=v1;v[2].color=color;
	v[3].x=x3;v[3].y=y3;v[3].u=u0;v[3].v=v1;v[3].color=color;
	
	return 0;
}

int gxtkGraphics::ReadPixels( Array<int> pixels,int x,int y,int width,int height,int offset,int pitch ){

	Flush();
	
	D3D11_RECT r=DisplayRect( x,y,width,height );
	
	ID3D11Texture2D *backBuffer=0;
	DXASS( BBWin8Game::Win8Game()->GetSwapChain()->GetBuffer( 0,__uuidof( ID3D11Texture2D ),(void**)&backBuffer ) );

	D3D11_TEXTURE2D_DESC txdesc;
	ZEROMEM( txdesc );
	txdesc.Width=r.right-r.left;
	txdesc.Height=r.bottom-r.top;
	txdesc.MipLevels=1;
	txdesc.ArraySize=1;
	txdesc.Format=DXGI_FORMAT_B8G8R8A8_UNORM;
	txdesc.SampleDesc.Count=1;
	txdesc.SampleDesc.Quality=0;
	txdesc.Usage=D3D11_USAGE_STAGING;
	txdesc.BindFlags=0;
	txdesc.CPUAccessFlags=D3D11_CPU_ACCESS_READ;
	txdesc.MiscFlags=0;

	ID3D11Texture2D *texture=0;
	DXASS( d3dDevice->CreateTexture2D( &txdesc,0,&texture ) );
	
	D3D11_BOX box={r.left,r.top,0,r.right,r.bottom,1};
	d3dContext->CopySubresourceRegion( texture,0,0,0,0,backBuffer,0,&box );
	
	D3D11_MAPPED_SUBRESOURCE msr;
	ZEROMEM( msr );
	d3dContext->Map( texture,0,D3D11_MAP_READ,0,&msr );
	
//	char buf[256];
//	sprintf( buf,"Mapped! pData=%p, RowPitch=%i, DepthPitch=%i\n",msr.pData,msr.RowPitch,msr.DepthPitch );
//	OutputDebugStringA( buf );

	unsigned char *pData=(unsigned char*)msr.pData;

	int devrot=BBWin8Game::Win8Game()->GetDeviceRotation();

	if( devrot==0 ){
		for( int py=0;py<height;++py ){
			memcpy( &pixels[offset+py*pitch],pData+py*msr.RowPitch,width*4 );
		}
	}else if( devrot==1 ){
		for( int py=0;py<height;++py ){
			int *d=&pixels[offset+py*pitch];
			unsigned char *p=pData+(height-py-1)*4;
			for( int px=0;px<width;++px ){
				*d++=*(int*)p;
				p+=msr.RowPitch;
			}
		}
	}else if( devrot==2 ){
		for( int py=0;py<height;++py ){
			int *d=&pixels[offset+py*pitch];
			unsigned char *p=pData+(height-py-1)*msr.RowPitch+(width-1)*4;
			for( int px=0;px<width;++px ){
				*d++=*(int*)p;
				p-=4;
			}
		}
	}else if( devrot==3 ){
		for( int py=0;py<height;++py ){
			int *d=&pixels[offset+py*pitch];
			unsigned char *p=pData+(width-1)*msr.RowPitch+py*4;
			for( int px=0;px<width;++px ){
				*d++=*(int*)p;
				p-=msr.RowPitch;
			}
		}
	}

	d3dContext->Unmap( texture,0 );
	
	texture->Release();

	return 0;
}

static void *loadData( String path,int *sz ){
	FILE *f;
	if( _wfopen_s( &f,path.ToCString<wchar_t>(),L"rb" ) ) abort();
	fseek( f,0,SEEK_END );
	int n=ftell( f );
	fseek( f,0,SEEK_SET );
	void *p=malloc( n );
	if( fread( p,1,n,f )!=n ) abort();
	fclose( f );
	*sz=n;
	return p;
}

void gxtkGraphics::CreateD3dResources(){

	auto folder=Windows::ApplicationModel::Package::Current->InstalledLocation;
	
	String path=folder->Path;
	
	int sz;
	void *vs,*ps;

	vs=loadData( path+"/SimpleVertexShader.cso",&sz );
	DXASS( d3dDevice->CreateVertexShader( vs,sz,0,&simpleVertexShader ) );
	free( vs );
	
	vs=loadData( path+"/TextureVertexShader.cso",&sz );
	DXASS( d3dDevice->CreateVertexShader( vs,sz,0,&textureVertexShader ) );
	const D3D11_INPUT_ELEMENT_DESC vertexDesc[]={
		{ "POSITION", 0, DXGI_FORMAT_R32G32_FLOAT,   0, 0,  D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT,   0, 8,  D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "COLOR",    0, DXGI_FORMAT_R8G8B8A8_UNORM, 0, 16, D3D11_INPUT_PER_VERTEX_DATA, 0 }
	};
	DXASS( d3dDevice->CreateInputLayout( vertexDesc,ARRAYSIZE(vertexDesc),vs,sz,&inputLayout ) );
	free( vs );

	ps=loadData( path+"/SimplePixelShader.cso",&sz );
	DXASS( d3dDevice->CreatePixelShader( ps,sz,0,&simplePixelShader ) );
	free( ps );

	ps=loadData( path+"/TexturePixelShader.cso",&sz );
	DXASS( d3dDevice->CreatePixelShader( ps,sz,0,&texturePixelShader ) );
	free( ps );
	
	D3D11_BUFFER_DESC vbdesc;
	ZEROMEM( vbdesc );
	vbdesc.ByteWidth=MAX_VERTS*sizeof( Vertex );
	vbdesc.Usage=D3D11_USAGE_DYNAMIC;
	vbdesc.BindFlags=D3D11_BIND_VERTEX_BUFFER;
	vbdesc.CPUAccessFlags=D3D11_CPU_ACCESS_WRITE;
	DXASS( d3dDevice->CreateBuffer( &vbdesc,0,&vertexBuffer ) );
	
	D3D11_BUFFER_DESC ibdesc;
	ZEROMEM( ibdesc );
	ibdesc.ByteWidth=MAX_QUADS * 6 * sizeof( unsigned short );
	ibdesc.Usage=D3D11_USAGE_DEFAULT;
	ibdesc.BindFlags=D3D11_BIND_INDEX_BUFFER;
	DXASS( d3dDevice->CreateBuffer( &ibdesc,0,&indexBuffer ) );
	
	D3D11_BUFFER_DESC ibdesc2;
	ZEROMEM( ibdesc2 );
	ibdesc2.ByteWidth=(MAX_VERTS-2) * 3 * sizeof( unsigned short );
	ibdesc2.Usage=D3D11_USAGE_DEFAULT;
	ibdesc2.BindFlags=D3D11_BIND_INDEX_BUFFER;
	DXASS( d3dDevice->CreateBuffer( &ibdesc2,0,&indexBuffer2 ) );
	
	D3D11_BUFFER_DESC cbdesc;
	ZEROMEM( cbdesc );
	cbdesc.ByteWidth=sizeof( ShaderConstants );
	cbdesc.Usage=D3D11_USAGE_DEFAULT;
	cbdesc.BindFlags=D3D11_BIND_CONSTANT_BUFFER;
	DXASS( d3dDevice->CreateBuffer( &cbdesc,0,&constantBuffer ) );
	
	//Create alphaBlendState
	D3D11_BLEND_DESC abdesc;
	ZEROMEM( abdesc );
	abdesc.AlphaToCoverageEnable=FALSE;
	abdesc.IndependentBlendEnable=FALSE;
	abdesc.RenderTarget[0].BlendEnable=TRUE;
	abdesc.RenderTarget[0].SrcBlend=D3D11_BLEND_ONE;
	abdesc.RenderTarget[0].DestBlend=D3D11_BLEND_INV_SRC_ALPHA;
	abdesc.RenderTarget[0].BlendOp=D3D11_BLEND_OP_ADD;
	abdesc.RenderTarget[0].SrcBlendAlpha=D3D11_BLEND_ONE;
	abdesc.RenderTarget[0].DestBlendAlpha=D3D11_BLEND_ZERO;
	abdesc.RenderTarget[0].BlendOpAlpha=D3D11_BLEND_OP_ADD;
	abdesc.RenderTarget[0].RenderTargetWriteMask=D3D11_COLOR_WRITE_ENABLE_ALL;
	DXASS( d3dDevice->CreateBlendState( &abdesc,&alphaBlendState ) );
	
	//Additive blend state
	D3D11_BLEND_DESC pbdesc;
	ZEROMEM( pbdesc );
	memset( &pbdesc,0,sizeof(pbdesc) );
	pbdesc.AlphaToCoverageEnable=FALSE;
	pbdesc.IndependentBlendEnable=FALSE;
	pbdesc.RenderTarget[0].BlendEnable=TRUE;
	pbdesc.RenderTarget[0].SrcBlend=D3D11_BLEND_ONE;
	pbdesc.RenderTarget[0].DestBlend=D3D11_BLEND_ONE;
	pbdesc.RenderTarget[0].BlendOp=D3D11_BLEND_OP_ADD;
	pbdesc.RenderTarget[0].SrcBlendAlpha=D3D11_BLEND_ONE;
	pbdesc.RenderTarget[0].DestBlendAlpha=D3D11_BLEND_ZERO;
	pbdesc.RenderTarget[0].BlendOpAlpha=D3D11_BLEND_OP_ADD;
	pbdesc.RenderTarget[0].RenderTargetWriteMask=D3D11_COLOR_WRITE_ENABLE_ALL;
	DXASS( d3dDevice->CreateBlendState( &pbdesc,&additiveBlendState ) );
	
	//Create RasterizerState
	D3D11_RASTERIZER_DESC rsdesc;
	ZEROMEM( rsdesc );
	rsdesc.FillMode=D3D11_FILL_SOLID;
	rsdesc.CullMode=D3D11_CULL_NONE;
	rsdesc.DepthClipEnable=TRUE;
	rsdesc.ScissorEnable=TRUE;
	rsdesc.MultisampleEnable=FALSE;
	rsdesc.AntialiasedLineEnable=FALSE;
	DXASS( d3dDevice->CreateRasterizerState( &rsdesc,&rasterizerState ) );
	
	// Create DepthStencilState
	D3D11_DEPTH_STENCIL_DESC dsdesc;
	ZEROMEM( dsdesc );
	dsdesc.DepthEnable=FALSE;
	dsdesc.StencilEnable=FALSE;
	DXASS( d3dDevice->CreateDepthStencilState( &dsdesc,&depthStencilState ) );

	// Create SamplerState
	D3D11_SAMPLER_DESC ssdesc;
	ZEROMEM( ssdesc );
	ssdesc.Filter=D3D11_FILTER_MIN_MAG_MIP_LINEAR;
	ssdesc.AddressU=D3D11_TEXTURE_ADDRESS_CLAMP;
	ssdesc.AddressV=D3D11_TEXTURE_ADDRESS_CLAMP;
	ssdesc.AddressW=D3D11_TEXTURE_ADDRESS_CLAMP;
	ssdesc.MinLOD=-FLT_MAX;
	ssdesc.MaxLOD=+FLT_MAX;
	ssdesc.MaxAnisotropy=16;
	ssdesc.ComparisonFunc=D3D11_COMPARISON_NEVER;
	DXASS( d3dDevice->CreateSamplerState( &ssdesc,&samplerState ) );
}

gxtkSurface::gxtkSurface( gxtkGraphics *graphics ):
graphics( graphics ),texture(0),width(0),height(0),uscale(0),vscale(0){
}

gxtkSurface::~gxtkSurface(){
	Discard();
}

void gxtkSurface::SetTexture( ID3D11Texture2D *texture ){
	this->texture=texture;
	
	D3D11_TEXTURE2D_DESC txdesc;
	ZEROMEM( txdesc );
	texture->GetDesc( &txdesc );
	this->width=txdesc.Width;
	this->height=txdesc.Height;
	this->uscale=1.0f/txdesc.Width;
	this->vscale=1.0f/txdesc.Height;

	D3D11_SHADER_RESOURCE_VIEW_DESC rvdesc;
	ZEROMEM( rvdesc );
	rvdesc.Format=txdesc.Format;	//DXGI_FORMAT_B8G8R8A8_UNORM;
	rvdesc.ViewDimension=D3D11_SRV_DIMENSION_TEXTURE2D;
	rvdesc.Texture2D.MostDetailedMip=0;
	rvdesc.Texture2D.MipLevels=1;
	
	DXASS( graphics->d3dDevice->CreateShaderResourceView( texture,&rvdesc,&resourceView ) );
}

void gxtkSurface::Discard(){
	if( texture ){
		texture->Release();
		texture=0;
	}
}

int gxtkSurface::Width(){
	return width;
}

int gxtkSurface::Height(){
	return height;
}

//***** gxtkAudio.h *****

class gxtkSample;
class VoiceCallback;
class MediaEngineNotify;

struct gxtkChannel{
	int state,id;
	gxtkSample *sample;
	IXAudio2SourceVoice *voice;
	
	gxtkChannel():state(0),id(0),sample(0),voice(0){}
};

class gxtkAudio : public Object{
public:

	IXAudio2 *xaudio2;
	IXAudio2MasteringVoice *masterVoice;
	
	gxtkChannel channels[33];
	
	MediaEngineNotify *mediaEngineNotify;
	IMFMediaEngine *mediaEngine;
	
	int musicState;
	bool musicLoop;
	
	void MediaEvent( DWORD ev );
	
	gxtkAudio();
	
	virtual void mark();
	
	virtual int Suspend();
	virtual int Resume();
	
	virtual gxtkSample *LoadSample__UNSAFE__( gxtkSample *sample,String path );
	virtual gxtkSample *LoadSample( String path );
	
	virtual int PlaySample( gxtkSample *sample,int channel,int flags );
	virtual int StopChannel( int channel );
	virtual int PauseChannel( int channel );
	virtual int ResumeChannel( int channel );
	virtual int ChannelState( int channel );
	virtual int SetVolume( int channel,float volume );
	virtual int SetPan( int channel,float pan );
	virtual int SetRate( int channel,float rate );

	virtual int PlayMusic( String path,int flags );
	virtual int StopMusic();
	virtual int PauseMusic();
	virtual int ResumeMusic();
	virtual int MusicState();
	virtual int SetMusicVolume( float volume );
};

class gxtkSample : public Object{
public:

	gxtkAudio *audio;
	WAVEFORMATEX wformat;
	XAUDIO2_BUFFER xbuffer;
	VoiceCallback *callbacks[16];
	IXAudio2SourceVoice *voices[16];
	bool free[16];

	gxtkSample( gxtkAudio *audio );
	~gxtkSample();
	
	void SetData( unsigned char *data,int length,int channels,int format,int hertz );
	
	int Alloc( bool loop );
	bool IsFree( int id );

	IXAudio2SourceVoice *GetVoice( int id );

	virtual int Discard();
};

//***** gxtkAudio.cpp *****

class MediaEngineNotify : public IMFMediaEngineNotify{
    long _refs;
	gxtkAudio *_audio;
public:
	MediaEngineNotify( gxtkAudio *audio ):_refs( 1 ),_audio( audio ){
	}
	
	STDMETHODIMP QueryInterface( REFIID riid,void **ppv ){
		if( riid==__uuidof( IMFMediaEngineNotify ) ){
			*ppv=static_cast<IMFMediaEngineNotify*>(this);
		}else{
			*ppv=0;
			return E_NOINTERFACE;
		}
		AddRef();
		return S_OK;
	}      
	
	STDMETHODIMP_(ULONG) AddRef(){
		return InterlockedIncrement( &_refs );
	}
	
	STDMETHODIMP_(ULONG) Release(){
		LONG refs=InterlockedDecrement( &_refs );
		if( !refs ) delete this;
		return refs;
	}

	STDMETHODIMP EventNotify( DWORD meEvent,DWORD_PTR param1,DWORD param2 ){
		if( meEvent==MF_MEDIA_ENGINE_EVENT_NOTIFYSTABLESTATE ){
			SetEvent( reinterpret_cast<HANDLE>( param1 ) );
		}else{
			_audio->MediaEvent( meEvent );
		}
		return S_OK;
	}
};

gxtkAudio::gxtkAudio():musicState( 0 ),musicLoop( false ){

	DXASS( MFStartup( MF_VERSION ) );

	//Create xaudio2
	DXASS( XAudio2Create( &xaudio2,0,XAUDIO2_DEFAULT_PROCESSOR ) );
	DXASS( xaudio2->CreateMasteringVoice( &masterVoice ) );
	
	//Media engine attrs
	mediaEngineNotify=new MediaEngineNotify( this );
	
	IMFAttributes *attrs;
	DXASS( MFCreateAttributes( &attrs,1 ) );
	DXASS( attrs->SetUnknown( MF_MEDIA_ENGINE_CALLBACK,(IUnknown*)mediaEngineNotify ) );
	
	//Create media engine
	IMFMediaEngineClassFactory *factory;
	DXASS( CoCreateInstance( CLSID_MFMediaEngineClassFactory,0,CLSCTX_ALL,IID_PPV_ARGS( &factory ) ) );
	
#if WINDOWS_PHONE_8
	DXASS( factory->CreateInstance( 0,attrs,&mediaEngine ) );
#else
	DXASS( factory->CreateInstance( MF_MEDIA_ENGINE_AUDIOONLY,attrs,&mediaEngine ) );
#endif

	factory->Release();
	attrs->Release();
}

void gxtkAudio::MediaEvent( DWORD ev ){
	if( ev==MF_MEDIA_ENGINE_EVENT_LOADEDMETADATA ){
//		Print( "MF_MEDIA_ENGINE_EVENT_LOADEDMETADATA" );
	}else if( ev==MF_MEDIA_ENGINE_EVENT_LOADEDDATA ){
//		Print( "MF_MEDIA_ENGINE_EVENT_LOADEDDATA" );
	}else if( ev==MF_MEDIA_ENGINE_EVENT_CANPLAY ){
//		Print( "MF_MEDIA_ENGINE_EVENT_CANPLAY" );
	}else if( ev==MF_MEDIA_ENGINE_EVENT_CANPLAYTHROUGH ){
//		Print( "MF_MEDIA_ENGINE_EVENT_CANPLAYTHROUGH" );
	}else if( ev==MF_MEDIA_ENGINE_EVENT_ERROR ){
//		Print( "MF_MEDIA_ENGINE_EVENT_ERROR" );
		musicState=0;
	}else{
//		Print( String( "MF_MEDIA_ENGINE_EVENT:" )+(int)ev );
	}
}

void gxtkAudio::mark(){
	for( int i=0;i<32;++i ){
		gxtkChannel *chan=&channels[i];
		if( chan->state && chan->sample->IsFree( chan->id ) ) chan->state=0;
		if( chan->state ) gc_mark( chan->sample );
	}
}

gxtkSample *gxtkAudio::LoadSample__UNSAFE__( gxtkSample *sample,String path ){
	int length=0,channels=0,format=0,hertz=0;
	
	unsigned char *data=BBWin8Game::Win8Game()->LoadAudioData( path,&length,&channels,&format,&hertz );
	
	if( data ){
		sample->SetData( data,length,channels,format,hertz );
	}else{
		sample=0;
	}
	return sample;
}

gxtkSample *gxtkAudio::LoadSample( String path ){
	return LoadSample__UNSAFE__( new gxtkSample( this ),path );
}

int gxtkAudio::Suspend(){
	return 0;
}

int gxtkAudio::Resume(){
	return 0;
}

int gxtkAudio::PlaySample( gxtkSample *sample,int channel,int flags ){

	gxtkChannel *chan=&channels[channel];
	
	StopChannel( channel );
	
	int id=sample->Alloc( (flags&1)==1 );
	if( id<0 ) return -1;
	
	IXAudio2SourceVoice *voice=sample->GetVoice( id );
	
	chan->state=1;
	chan->id=id;
	chan->sample=sample;
	chan->voice=voice;
			
	voice->Start();
	return 0;
}

int gxtkAudio::StopChannel( int channel ){

	gxtkChannel *chan=&channels[channel];
	
	if( chan->state!=0 ){
		chan->voice->Stop( 0,0 );
		chan->voice->FlushSourceBuffers();
		chan->state=0;
	}

	return 0;
}

int gxtkAudio::PauseChannel( int channel ){

	gxtkChannel *chan=&channels[channel];
	
	if( chan->state==1 ){
		chan->voice->Stop( 0,0 );
		chan->state=2;
	}
	return 0;
}

int gxtkAudio::ResumeChannel( int channel ){

	gxtkChannel *chan=&channels[channel];
	
	if( chan->state==2 ){
		chan->voice->Start();
		chan->state=1;
	}

	return 0;
}

int gxtkAudio::ChannelState( int channel ){

	gxtkChannel *chan=&channels[channel];
	
	if( chan->state && chan->sample->IsFree( chan->id ) ) chan->state=0;
	
	return chan->state;
}

int gxtkAudio::SetVolume( int channel,float volume ){
	return 0;
}

int gxtkAudio::SetPan( int channel,float pan ){
	return 0;
}

int gxtkAudio::SetRate( int channel,float rate ){
	return 0;
}

int gxtkAudio::PlayMusic( String path,int flags ){

	StopMusic();

	//should really be PathToUrl...?
	path=BBWin8Game::Win8Game()->PathToFilePath( path );
	
	int sz=path.Length()*2;
	int *p=(int*)malloc( 4+sz+2 );
	*p=sz;memcpy( p+1,path.ToCString<wchar_t>(),sz+2 );

	musicLoop=(flags&1)==1;

	mediaEngine->SetLoop( musicLoop );
	
	mediaEngine->SetSource( (BSTR)(p+1) );
	
	mediaEngine->Play();
	
	musicState=1;
	
	free( p );
	
	return 0;
}

int gxtkAudio::StopMusic(){

	if( !musicState ) return 0;
	
	mediaEngine->Pause();
	
	musicState=0;

	return 0;
}

int gxtkAudio::PauseMusic(){

	if( musicState!=1 ) return 0;
	
	mediaEngine->Pause();
	
	musicState=2;
	
	return 0;
}

int gxtkAudio::ResumeMusic(){

	if( musicState!=2 ) return 0;
	
	mediaEngine->Play();
	
	musicState=1;
	
	return 0;
}

int gxtkAudio::MusicState(){

	if( musicState && !musicLoop && mediaEngine->IsEnded() ) musicState=0;
	
	return musicState;
}

int gxtkAudio::SetMusicVolume( float volume ){

	mediaEngine->SetVolume( volume );

	return 0;
}

// ***** gxtkSample *****

class VoiceCallback : public IXAudio2VoiceCallback{
public:

	gxtkSample *sample;
	int id;

	VoiceCallback( gxtkSample *sample,int id ){
		this->sample=sample;
		this->id=id;
	}

	void _stdcall OnStreamEnd(){
	}
	
	void _stdcall OnVoiceProcessingPassEnd(){
	}
	
	void _stdcall OnVoiceProcessingPassStart( UINT32 SamplesRequired ){
	}
	
	void _stdcall OnBufferEnd( void *pBufferContext ){
		sample->free[id]=true;
	}
	
	void _stdcall OnBufferStart( void *pBufferContext ) {
	}
	
	void _stdcall OnLoopEnd( void *pBufferContext ){
	}
	
	void _stdcall OnVoiceError( void *pBufferContext,HRESULT Error ){
	}
};

gxtkSample::gxtkSample( gxtkAudio *audio ):audio( audio ){
	ZEROMEM( wformat );
	ZEROMEM( xbuffer );
	ZEROMEM( voices );
	ZEROMEM( callbacks );
	ZEROMEM( free );
}

gxtkSample::~gxtkSample(){
	Discard();
}

void gxtkSample::SetData( unsigned char *data,int length,int channels,int format,int hertz ){
	wformat.wFormatTag=WAVE_FORMAT_PCM;
	wformat.nChannels=channels;
	wformat.nSamplesPerSec=hertz;
	wformat.nAvgBytesPerSec=channels*format*hertz;
	wformat.nBlockAlign=channels*format;
	wformat.wBitsPerSample=format*8;
	
	xbuffer.AudioBytes=length*channels*format;
	xbuffer.pAudioData=data;
}

int gxtkSample::Alloc( bool loop ){
	if( !xbuffer.pAudioData ) return -1;

	int st=loop ? 8 : 0;
	
	for( int i=st;i<st+8;++i ){

		IXAudio2SourceVoice *voice=voices[i];
		
		if( !voice ){
		
			VoiceCallback *cb=new VoiceCallback( this,i );
			if( FAILED( audio->xaudio2->CreateSourceVoice( &voice,&wformat,0,XAUDIO2_DEFAULT_FREQ_RATIO,cb,0,0 ) ) ){
				delete cb;
				return 0;
			}
			callbacks[i]=cb;
			voices[i]=voice;
			
		}else if( !free[i] ){
			continue;
		}
		
		xbuffer.LoopCount=loop ? XAUDIO2_LOOP_INFINITE : 0;
		voice->SubmitSourceBuffer( &xbuffer,0 );
		free[i]=false;
		
		return i;
	}
	return -1;
}

IXAudio2SourceVoice *gxtkSample::GetVoice( int id ){
	return voices[id];
}

bool gxtkSample::IsFree( int id ){
	return free[id];
}

int gxtkSample::Discard(){
	if( !xbuffer.pAudioData ) return 0;

	for( int i=0;i<16 && voices[i];++i ){
		voices[i]->DestroyVoice();
		delete callbacks[i];
	}
	::free( (void*)xbuffer.pAudioData );
	xbuffer.pAudioData=0;
	
	return 0;
}
