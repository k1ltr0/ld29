
function createWebSocket( url ){
	return new WebSocket( url );
}

function createWebSocket2( url,protocols ){
	return new WebSocket( url,protocols );
}
