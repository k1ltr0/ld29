
//${PACKAGE_BEGIN}
package com.monkey;
//${PACKAGE_END}

//${IMPORTS_BEGIN}
//${IMPORTS_END}

class MonkeyConfig{
//${CONFIG_BEGIN}
//${CONFIG_END}
}

//${TRANSCODE_BEGIN}
//${TRANSCODE_END}
